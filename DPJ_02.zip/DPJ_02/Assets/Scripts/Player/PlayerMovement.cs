using UnityEngine;
using UnityEngine.InputSystem;
public class PlayerMovement : MonoBehaviour
{

    [Header("Config")]
    [SerializeField] private float speed;

    private Vector2 moveDirection;

    private Action actions;

    private Rigidbody2D rb;

    private Animator animator;

    private void Update()
    {
        ReadMovement();
        
    }

    private void Awake()
    {
        actions = new Action();
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();

    }

    private void OnEnable()
    {
        actions.Movement.Enable();
    }
    private void OnDisable()
    {
        actions.Movement.Disable();
    }
    private void ReadMovement()
    {
        moveDirection = actions.Movement.Move.ReadValue<Vector2>().normalized;

        if (moveDirection == Vector2.zero)
        {
            return;
        }

        animator.SetFloat("MoveX", moveDirection.x);
        animator.SetFloat("MoveY", moveDirection.y);
    }
    private void Move()
    {
        rb.MovePosition(rb.position + moveDirection * (speed * Time.fixedDeltaTime));
    }
    private void FixedUpdate()
    {
        Move();
    }
}